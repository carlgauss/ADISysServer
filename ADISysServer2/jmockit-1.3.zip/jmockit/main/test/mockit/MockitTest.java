/*
 * Copyright (c) 2006-2013 Rogério Liesenfeld
 * This file is subject to the terms of the MIT license (see LICENSE.txt).
 */
package mockit;

import javax.security.auth.callback.*;
import javax.security.auth.login.*;

import static org.junit.Assert.*;
import org.junit.*;

import mockit.internal.state.*;

public final class MockitTest
{
   Class<?> classRedefined;
   static class RealClass { int doSomething() { return 1; } }

   @Test
   public void redefineMethodsWithEmptyMockClass()
   {
      Mockit.setUpMock(RealClass.class, EmptyMockClass.class);

      assertEquals(0, TestRun.mockFixture().getRedefinedClassCount());
      assertEquals(0, TestRun.getMockClasses().getRegularMocks().getInstanceCount());
      assertEquals(1, new RealClass().doSomething());
      assertEquals(2, new EmptyMockClass().utilityMethod());
   }

   public static class EmptyMockClass { int utilityMethod() { return 2; } }

   @Test
   public void redefineMethodsWithMockClass()
   {
      classRedefined = RealClass.class;
      Mockit.setUpMock(RealClass.class, MockClass.class);

      assertClassRedefined();
      assertEquals(0, TestRun.getMockClasses().getRegularMocks().getInstanceCount());
   }

   public static class MockClass { @Mock public int doSomething() { return -1; } }

   private void assertClassRedefined()
   {
      assertEquals(1, TestRun.mockFixture().getRedefinedClassCount());
      assertTrue(TestRun.mockFixture().containsRedefinedClass(classRedefined));
   }

   @Test
   public void redefineMethodsWithMockInstance()
   {
      classRedefined = RealClass.class;
      MockClass mockInstance = new MockClass();
      Mockit.setUpMock(RealClass.class, mockInstance);

      assertClassRedefined();
      assertEquals(1, TestRun.getMockClasses().getRegularMocks().getInstanceCount());
      assertTrue(TestRun.getMockClasses().getRegularMocks().containsInstance(mockInstance));
   }

   @Test(expected = IllegalArgumentException.class)
   public void redefineMethodsWithMockMethodForNoCorrespondingRealMethod()
   {
      Mockit.setUpMock(RealClass.class, MockClassWithMethodWithoutRealMethod.class);
   }

   public static class MockClassWithMethodWithoutRealMethod
   {
      @Mock
      public void doSomethingElse() {}
   }

   @Test(expected = IllegalArgumentException.class)
   public void redefineMethodsWithIncompatibleReturnTypeBetweenRealAndMockMethod()
   {
      Mockit.setUpMock(RealClass2.class, MockClassWithIncompatibleReturnType.class);

      // Force the compiler to generate a synthetic "String access$0(RealClass2)" method:
      new RealClass2().dummy();
   }

   @SuppressWarnings("InnerClassMayBeStatic")
   class RealClass2
   {
      @SuppressWarnings("UnusedDeclaration")
      private String dummy() { return null; }
   }

   public static class MockClassWithIncompatibleReturnType { @Mock public int dummy() { return 0; } }

   @Test
   public void mockJREMethodAndConstructor() throws Exception
   {
      Mockit.setUpMock(LoginContext.class, new MockLoginContext());

      new LoginContext("test", (CallbackHandler) null).login();
   }

   public static class MockLoginContext
   {
      @Mock
      public void $init(String name, CallbackHandler callbackHandler)
      {
         assertEquals("test", name);
         assertNull(callbackHandler);
      }

      @Mock
      public void login() {}
   }
}
