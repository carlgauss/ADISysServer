package integrationTests;

abstract class AbstractClassWithNoExecutableLines
{
   protected int anIntField;
   
   abstract void doSomething(String s, boolean b);
   abstract int returnValue();
}